/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.dao;

/**
 *
 * @author lucas
 */

import model.bean.Servico;
import conexao.DBConnection;
import model.bean.Servico;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

public class ServicoDAO {

    // Método para criar um serviço
    public void criarServico(Servico servico) {
        String sql = "INSERT INTO servicos (nome, descricao, preco) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, servico.getNome()); // Agora está usando 'nome'
            stmt.setString(2, servico.getDescricao());
            stmt.setDouble(3, servico.getPreco());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para listar todos os serviços
    public List<Servico> listarServicos() {
        List<Servico> servicos = new ArrayList<>();
        String sql = "SELECT * FROM servicos";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Servico servico = new Servico(
                        rs.getInt("id"),
                        rs.getString("nome"),  // Incluindo 'nome'
                        rs.getString("descricao"),
                        rs.getDouble("preco")
                );
                servicos.add(servico);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return servicos;
    }

    // Método para excluir um serviço
    public boolean excluirServico(int id) {
        String sql = "DELETE FROM servicos WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);

            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para editar um serviço
    public boolean editarServico(Servico servico) {
        String sql = "UPDATE servicos SET nome = ?, descricao = ?, preco = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, servico.getNome());  // Alteração para incluir 'nome'
            stmt.setString(2, servico.getDescricao());
            stmt.setDouble(3, servico.getPreco());
            stmt.setInt(4, servico.getId());

            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para salvar um novo serviço no banco de dados
    public boolean salvar(Servico servico) {
        String sql = "INSERT INTO servicos (nome, descricao, preco) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, servico.getNome());  // Adicionando 'nome' ao método
            stmt.setString(2, servico.getDescricao());
            stmt.setDouble(3, servico.getPreco());

            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}

